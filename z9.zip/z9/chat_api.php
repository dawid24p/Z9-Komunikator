<?php declare(strict_types=1);
require __DIR__.'/chat_common.php';
header('Content-Type: application/json; charset=UTF-8');
$u=chat_user();
try{
    if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
        if(!hash_equals(cloud_csrf(),posted('csrf'))){http_response_code(403);echo json_encode(['error'=>'Formularz wygasł. Odśwież stronę.']);exit;}
        $action=posted('action');
        if(in_array($action,['edit','delete'],true)){
            chat_modify(db(),$u,(int)posted('id'),$action,trim(posted('post')));
            echo json_encode(['ok'=>true]);exit;
        }
        $recipient=posted('recipient');$text=trim(posted('post'));$d=db();
        $s=$d->prepare('SELECT username FROM z6_users WHERE username=?');$s->bind_param('s',$recipient);$s->execute();$target=$s->get_result()->fetch_assoc();
        if(!$target)throw new InvalidArgumentException('Wybierz istniejącego odbiorcę.');$recipient=$target['username'];
        if(mb_strlen($text)>10000)throw new InvalidArgumentException('Wiadomość może mieć do 10 000 znaków.');
        $f=$_FILES['attachment']??null;$relative=null;$dest=null;$filename=null;$mime=null;$kind='text';
        if($f!==null&&(!is_array($f)||!isset($f['error'])||!is_int($f['error'])))throw new InvalidArgumentException('Nieprawidłowy plik.');
        if($f!==null&&$f['error']!==UPLOAD_ERR_NO_FILE){
            if($f['error']!==UPLOAD_ERR_OK)throw new InvalidArgumentException('Nie udało się przesłać pliku. Sprawdź limit przesyłania serwera.');
            if(!is_string($f['tmp_name'])||!is_uploaded_file($f['tmp_name']))throw new InvalidArgumentException('Nieprawidłowy plik.');
            $filename=mb_substr(basename(str_replace('\\','/',(string)$f['name'])),0,240);
            $filename=preg_replace('/[\x00-\x1f\x7f]/u','_',$filename)?:'plik';
            $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name'])?:'application/octet-stream';
            $ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));$kind='file';
            if(in_array($ext,['png','jpg','jpeg','gif'],true)&&@getimagesize($f['tmp_name'])!==false&&in_array($mime,['image/png','image/jpeg','image/gif'],true))$kind='image';
            elseif($ext==='mp3'&&in_array($mime,['audio/mpeg','audio/mp3','application/octet-stream'],true)){$kind='audio';$mime='audio/mpeg';}
            elseif($ext==='mp4'&&in_array($mime,['video/mp4','application/mp4','application/octet-stream'],true)){$kind='video';$mime='video/mp4';}
            $home=cloud_home_for($u['username']);$folder=$home.'/messages';
            if(is_link($folder))throw new RuntimeException('Nieprawidłowy katalog.');
            if(!is_dir($folder)&&!mkdir($folder,0700))throw new RuntimeException('Błąd katalogu.');
            $token=bin2hex(random_bytes(24));$relative=$u['username'].'/messages/'.$token;$dest=CLOUD_STORAGE.'/'.$relative;
            if(!move_uploaded_file($f['tmp_name'],$dest))throw new RuntimeException('Błąd zapisu pliku.');chmod($dest,0600);
        }
        if($text===''&&$relative===null)throw new InvalidArgumentException('Wpisz wiadomość lub wybierz plik.');
        try{
            $d->begin_transaction();$s=$d->prepare('INSERT INTO messages(message,user,recipient,kind,filename,mime) VALUES (?,?,?,?,?,?)');$sender=$u['username'];
            if($text!==''&&$relative===null){$k='text';$null=null;$s->bind_param('ssssss',$text,$sender,$recipient,$k,$null,$null);$s->execute();}
            if($relative!==null){$s=$d->prepare('INSERT INTO messages(message,user,recipient,kind,filename,mime,caption) VALUES (?,?,?,?,?,?,?)');$s->bind_param('sssssss',$relative,$sender,$recipient,$kind,$filename,$mime,$text);$s->execute();}
            $d->commit();
        }catch(Throwable $e){$d->rollback();if($dest!==null)unlink($dest);throw $e;}
        session_write_close();echo json_encode(['ok'=>true]);
    }else{
        if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){http_response_code(405);header('Allow: GET, POST');exit;}
        session_write_close();$d=db();$after=max(0,(int)($_GET['after']??0));$before=max(0,(int)($_GET['before']??0));
        $peer=$_GET['peer']??'';if(!is_string($peer))throw new InvalidArgumentException('Nieprawidłowy odbiorca.');
        $rows=chat_messages($d,$u,$after,$before,$peer);$users=$d->query('SELECT username,avatar FROM z6_users ORDER BY username')->fetch_all(MYSQLI_ASSOC);
        $floor=max(0,(int)($_GET['floor']??0));$updates=$floor>0?chat_messages($d,$u,$floor-1,0,$peer,true):[];
        echo json_encode(['messages'=>$rows,'updates'=>$updates,'profiles'=>$users,'users'=>array_column($users,'username'),'more'=>count($rows)===50],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
    }
}catch(InvalidArgumentException $e){http_response_code(422);echo json_encode(['error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);}
catch(Throwable $e){error_log('Z9 chat: '.get_class($e));http_response_code(500);echo json_encode(['error'=>'Nie udało się wykonać operacji. Spróbuj ponownie.']);}
