<?php declare(strict_types=1);
require __DIR__.'/chat_common.php';$u=cloud_user();head('Komunikator');
?>
<section id="chat-app" data-user="<?=h($u['username'])?>" data-admin="<?=chat_admin($u)?'1':'0'?>">
<div class="d-flex flex-wrap justify-content-between gap-2 mb-3"><p class="text-body-secondary mb-0">Wybierz użytkownika i rozpocznij rozmowę.</p><span id="chat-status" role="status">Łączenie…</span></div>
<div class="chat-layout">
<aside class="card chat-sidebar" aria-label="Lista użytkowników"><div class="p-3 border-bottom"><h2 class="h5 mb-0">Użytkownicy</h2></div><div id="chat-users" class="chat-users"></div></aside>
<section class="card chat-conversation" aria-labelledby="chat-title">
<div class="p-3 border-bottom"><h2 id="chat-title" class="h5 mb-0 d-flex align-items-center gap-3">Wybierz rozmowę</h2></div>
<div class="chat-history" id="chat-history"><button class="btn btn-outline-secondary btn-sm mb-3" id="chat-older" type="button" hidden>Wczytaj starsze wiadomości</button><p id="chat-empty" class="text-body-secondary p-3">Wybierz użytkownika z listy po lewej.</p><div id="chat-messages" aria-live="polite" aria-relevant="additions" aria-label="Wiadomości"></div></div>
<form id="chat-form" class="chat-composer border-top p-3" method="post" action="chat_api.php" enctype="multipart/form-data" data-full-navigation="true">
<input type="hidden" name="csrf" value="<?=h(cloud_csrf())?>"><input type="hidden" name="recipient" id="chat-recipient">
<fieldset id="chat-compose-fields" disabled>
<div id="chat-attachment" class="chat-attachment mb-3" hidden><div id="chat-preview"></div><span id="chat-filename"></span><button id="chat-remove-file" class="btn btn-sm btn-outline-secondary" type="button" aria-label="Usuń załącznik">×</button></div>
<div id="chat-editing" class="mb-2 text-info" hidden>Edycja wiadomości <button type="button" id="chat-cancel-edit" class="btn btn-sm btn-outline-secondary ms-2">Anuluj</button></div>
<div class="chat-input-row"><button class="btn btn-outline-secondary chat-icon" type="button" id="chat-attach" aria-label="Dodaj załącznik" title="Dodaj załącznik"><span aria-hidden="true">+</span></button><input type="file" id="chat-file" name="attachment" hidden>
<label class="visually-hidden" for="chat-text">Napisz wiadomość</label><textarea class="form-control" id="chat-text" name="post" maxlength="10000" rows="1" placeholder="Napisz wiadomość…"></textarea>
<button class="btn btn-primary chat-icon" type="submit" aria-label="Wyślij wiadomość" title="Wyślij wiadomość (Enter)"><span aria-hidden="true">→</span></button></div>

</fieldset><p id="chat-error" class="text-danger mt-2 mb-0" role="alert"></p>
</form></section></div></section>
<?php foot(); ?>
