<?php declare(strict_types=1);require __DIR__.'/common.php';require_login();
if(($_SERVER['REQUEST_METHOD']??'')!=='POST'){http_response_code(405);header('Allow: POST');exit('Wymagane POST.');}
if(!isset($_SESSION['b_csrf'])||!hash_equals($_SESSION['b_csrf'],posted('csrf'))){http_response_code(403);exit('Formularz wygasł.');}
$values=[];for($i=1;$i<=5;$i++){$v=posted('x'.$i);if($v===''||!is_numeric($v)||!is_finite((float)$v)||abs((float)$v)>1e9){$_SESSION['b_notice']='Podaj pięć poprawnych liczb od -1000000000 do 1000000000.';redirect('b_formularz.php');}$values[]=(float)$v;}
try{$d=db();$s=$d->prepare('INSERT INTO pomiary(x1,x2,x3,x4,x5) VALUES (?,?,?,?,?)');$s->bind_param('ddddd',...$values);$s->execute();$s->close();$d->close();$_SESSION['b_notice']='Pomiar zapisany. Klienci SSE i SCADA zaktualizują się automatycznie.';}catch(Throwable $e){error_log('Z9 B: błąd zapisu');$_SESSION['b_notice']='Nie udało się zapisać pomiaru.';}redirect('b_formularz.php');
