<?php declare(strict_types=1);
require __DIR__.'/common.php';head('Zadanie 9 — Komunikator');
?>
<p class="text-body-secondary">Wysyłaj prywatne wiadomości, zdjęcia, muzykę i filmy. Nowe wiadomości pojawiają się automatycznie.</p>
<div class="d-flex flex-wrap gap-3"><a class="btn btn-primary" href="chat.php">Otwórz komunikator</a><a class="btn btn-outline-primary" href="tasks.php">Panel wszystkich zadań</a></div>
<?php foot(); ?>
