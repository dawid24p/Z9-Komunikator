<?php declare(strict_types=1);$format='xml';require __DIR__.'/b_stream.php';
