<?php declare(strict_types=1);
require __DIR__.'/common.php';require_login();session_write_close();
header('Content-Type: text/event-stream; charset=UTF-8');
header('Cache-Control: no-cache, no-store, must-revalidate');header('X-Accel-Buffering: no');
ini_set('zlib.output_compression','0');while(ob_get_level()>0)ob_end_flush();
echo "retry: 2000\n\n";flush();
try{
$d=db();$last=null;$until=microtime(true)+20;
do{
 $row=$d->query('SELECT id,text1,datetime FROM ajax_from_db ORDER BY id DESC LIMIT 1')->fetch_assoc();
 $payload=json_encode($row?:['id'=>null,'text1'=>'Brak wpisów. Dodaj pierwszy tekst.','datetime'=>null],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
 if($payload!==$last){echo 'data: '.$payload."\n\n";$last=$payload;}else echo ": heartbeat\n\n";
 flush();if(connection_aborted())break;sleep(1);
}while(microtime(true)<$until);
$d->close();
}catch(Throwable $e){error_log('Z9 AJAX: błąd strumienia');echo "event: stream-error\ndata: Tymczasowy błąd odczytu danych.\n\n";flush();}
