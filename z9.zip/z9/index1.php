<?php declare(strict_types=1);require __DIR__.'/common.php';head('AJAX — cykliczny odczyt JSON'); ?>
<section class="card"><div class="card-body" data-ajax-json>
<p class="fs-3">Imię: <span class="status" aria-live="polite">Ładowanie…</span></p>
<p class="text-body-secondary mb-0" data-poll-status role="status">Pobieranie danych…</p>
</div></section>
<p class="mt-3">Dane są pobierane co 2 sekundy z <a href="my_file.json" target="_blank" rel="noopener">my_file.json</a>. Zmiana pola „imie” w pliku pojawi się tutaj bez odświeżania strony.</p>
<a href="index.php">← Zadanie 9</a>
<?php foot(); ?>
