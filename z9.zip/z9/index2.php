<?php declare(strict_types=1);require __DIR__.'/common.php';head('Baza danych — aktualizacja na żywo'); ?>
<section class="card"><div class="card-body" data-ajax-stream>
<h2 class="h6 text-body-secondary">Ostatni wpis</h2>
<div id="date" class="fs-3 text-break" style="white-space:pre-wrap" aria-live="polite">Oczekiwanie na dane…</div>
<p class="text-body-secondary mt-3" data-stream-date></p>
<p class="mb-0" data-stream-status role="status">Łączenie…</p>
</div></section>
<p class="mt-3"><a class="btn btn-primary" href="formularz.php" target="_blank" rel="noopener">Dodaj wpis w drugim oknie</a></p>
<p>Po zapisaniu nowego wpisu tekst pojawi się tutaj automatycznie. Serwer sprawdza bazę co sekundę.</p>
<a href="index.php">← Zadanie 9</a>
<?php foot(); ?>
