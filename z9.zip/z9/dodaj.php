<?php declare(strict_types=1);
require __DIR__.'/common.php';require_login();
if(($_SERVER['REQUEST_METHOD']??'')!=='POST'){http_response_code(405);header('Allow: POST');exit('Wymagane żądanie POST.');}
if(!isset($_SESSION['ajax_csrf'])||!hash_equals($_SESSION['ajax_csrf'],posted('csrf'))){http_response_code(403);exit('Formularz wygasł. Otwórz go ponownie.');}
$text=trim(posted('text1'));
if($text===''||!mb_check_encoding($text,'UTF-8')||mb_strlen($text,'UTF-8')>2000){$_SESSION['ajax_error']='Wpisz tekst od 1 do 2000 znaków.';redirect('formularz.php');}
try{$d=db();$s=$d->prepare('INSERT INTO ajax_from_db (text1) VALUES (?)');$s->bind_param('s',$text);$s->execute();$s->close();$d->close();$_SESSION['ajax_notice']='Wpis został zapisany. Podgląd na żywo zaktualizuje się automatycznie.';}
catch(Throwable $e){error_log('Z9 AJAX: błąd zapisu');$_SESSION['ajax_error']='Nie udało się zapisać wpisu. Spróbuj ponownie.';}
redirect('formularz.php');
