<?php declare(strict_types=1);$format='csv';require __DIR__.'/b_stream.php';
