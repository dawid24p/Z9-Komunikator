'use strict';
(function(){
 const avatarColors=new Map();
 function averageAvatarPixels(pixels){
  let red=0,green=0,blue=0,weight=0;
  for(let i=0;i<pixels.length;i+=4){const alpha=pixels[i+3]/255;red+=pixels[i]*alpha;green+=pixels[i+1]*alpha;blue+=pixels[i+2]*alpha;weight+=alpha;}
  return weight?`rgb(${Math.round(red/weight)}, ${Math.round(green/weight)}, ${Math.round(blue/weight)})`:'rgb(128, 128, 128)';
 }
 function avatarSource(path){return path&&/^[a-f0-9]{64}\.png$/.test(path)?'media/avatars/'+path:'media/default-avatar.svg';}
 function avatarColor(path){
  const src=avatarSource(path);if(avatarColors.has(src))return avatarColors.get(src);
  const result=new Promise(resolve=>{
   const image=new Image();image.onload=()=>{try{const canvas=document.createElement('canvas');canvas.width=image.naturalWidth||128;canvas.height=image.naturalHeight||128;const context=canvas.getContext('2d',{willReadFrequently:true});context.drawImage(image,0,0,canvas.width,canvas.height);resolve(averageAvatarPixels(context.getImageData(0,0,canvas.width,canvas.height).data));}catch(e){resolve('rgb(128, 128, 128)');}};image.onerror=()=>resolve('rgb(128, 128, 128)');image.src=src;
  });avatarColors.set(src,result);return result;
 }
 let dispose=null;
 function init(){
  if(dispose)dispose();const app=document.getElementById('chat-app');if(!app)return;
  let stopped=false,timer=null,highest=0,lowest=0,version=0,selected=null,polling=false,sending=false,namesKey='',editing=null,previewURL=null;let seen=new Set(),signatures=new Map(),profiles=new Map();
  const controller=new AbortController(),signal=controller.signal;
  dispose=()=>{stopped=true;clearTimeout(timer);controller.abort();if(previewURL)URL.revokeObjectURL(previewURL);};
  const list=app.querySelector('#chat-messages'),empty=app.querySelector('#chat-empty'),status=app.querySelector('#chat-status'),form=app.querySelector('#chat-form'),recipient=app.querySelector('#chat-recipient'),older=app.querySelector('#chat-older'),error=app.querySelector('#chat-error'),usersList=app.querySelector('#chat-users'),history=app.querySelector('#chat-history'),text=form.elements.post,file=form.elements.attachment,fields=app.querySelector('#chat-compose-fields'),attachment=app.querySelector('#chat-attachment');
  function el(tag,cls,value){const node=document.createElement(tag);if(cls)node.className=cls;if(value!==undefined)node.textContent=value;return node;}
  function avatar(name,path){const img=el('img','chat-avatar');img.src=avatarSource(path);img.alt='Profilowe '+name;return img;}
  function fileLabel(){
   if(previewURL){URL.revokeObjectURL(previewURL);previewURL=null;}const preview=app.querySelector('#chat-preview');preview.replaceChildren();attachment.hidden=!file.files.length;app.querySelector('#chat-filename').textContent=file.files.length?file.files[0].name:'';
   if(file.files.length){const chosen=file.files[0];if(/^(image|video|audio)\//.test(chosen.type)){previewURL=URL.createObjectURL(chosen);const media=el(chosen.type.startsWith('image/')?'img':chosen.type.startsWith('video/')?'video':'audio','chat-attachment-preview');media.src=previewURL;if(media.tagName!=='IMG')media.controls=true;else media.alt=chosen.name;preview.append(media);}else preview.append(el('span','chat-file-symbol','▤'));}
  }
  function cancelEdit(){const submit=form.querySelector('button[type="submit"]');submit.setAttribute('aria-label','Wyślij wiadomość');submit.title='Wyślij wiadomość (Enter)';editing=null;app.querySelector('#chat-editing').hidden=true;app.querySelector('#chat-attach').disabled=false;text.value='';resize();}
  function startEdit(row){
   if(sending)return;
   if(!selected)choose(row.recipient);
   cancelEdit();editing=Number(row.idk);fields.disabled=false;
   text.value=row.kind==='text'?(row.message||''):(row.caption||'');
   file.value='';fileLabel();error.textContent='';
   app.querySelector('#chat-editing').hidden=false;
   app.querySelector('#chat-attach').disabled=true;
   const submit=form.querySelector('button[type="submit"]');
   submit.setAttribute('aria-label','Zapisz zmiany');submit.title='Zapisz zmiany (Enter)';
   resize();form.scrollIntoView({behavior:'smooth',block:'nearest'});
   text.focus({preventScroll:true});text.setSelectionRange(text.value.length,text.value.length);
  }
  async function removeMessage(row){
   const data=new FormData();data.set('csrf',form.elements.csrf.value);data.set('action','delete');data.set('id',row.idk);
   try{await json('chat_api.php',{method:'POST',body:data});if(editing===Number(row.idk))cancelEdit();clearTimeout(timer);if(!polling)await poll();}catch(e){if(e.name!=='AbortError')error.textContent=e.message;}
  }
  function resize(){text.style.height='auto';text.style.height=Math.min(text.scrollHeight,150)+'px';}
  function choose(name){
   if(selected===name)return;cancelEdit();file.value='';fileLabel();version++;selected=name;highest=0;lowest=0;seen=new Set();signatures=new Map();list.replaceChildren();older.hidden=true;empty.hidden=false;empty.textContent='Wczytywanie wiadomości…';recipient.value=name;fields.disabled=!name||sending;error.textContent='';
   const heading=app.querySelector('#chat-title');heading.replaceChildren();if(name)heading.append(avatar(name,profiles.get(name)));heading.append(el('span','',name?(name===app.dataset.user?'Wiadomości do siebie':name):'Wszystkie wiadomości'));
   for(const button of usersList.children){const active=button.dataset.user===name;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));}
   clearTimeout(timer);if(!polling)poll();
  }
  function users(names,people=[]){
   profiles=new Map(people.map(p=>[p.username,p.avatar]));
   const key=JSON.stringify([names,people]);if(key===namesKey)return;namesKey=key;usersList.replaceChildren();
   for(const card of list.children){const path=profiles.get(card.dataset.author);avatarColor(path).then(color=>{card.style.borderInlineStartColor=color;});const photo=card.querySelector('.chat-author img');if(photo)photo.src=avatarSource(path);}
   const options=names.map(name=>({name,label:name===app.dataset.user?name+' (Ty)':name}));if(app.dataset.admin==='1')options.unshift({name:'',label:'Wszystkie wiadomości'});
   for(const item of options){const button=el('button','chat-user');button.type='button';button.dataset.user=item.name;button.append(item.name?avatar(item.name,profiles.get(item.name)):el('span','chat-user-avatar','☰'),el('span','',item.label));button.classList.toggle('active',selected===item.name);button.setAttribute('aria-pressed',String(selected===item.name));button.addEventListener('click',()=>choose(item.name),{signal});usersList.append(button);}
   if(selected!==null&&selected!==''&&!names.includes(selected)){selected=null;version++;list.replaceChildren();fields.disabled=true;recipient.value='';empty.hidden=false;empty.textContent='Wybierz użytkownika z listy.';app.querySelector('#chat-title').textContent='Wybierz rozmowę';}
  }
  function render(rows,initial=false,loadingOlder=false){
   const nearBottom=history.scrollHeight-history.scrollTop-history.clientHeight<100,previousHeight=history.scrollHeight;
   for(const row of rows){const id=Number(row.idk);const signature=JSON.stringify(row);if(signatures.get(id)===signature)continue;signatures.set(id,signature);seen.add(id);highest=Math.max(highest,id);lowest=lowest?Math.min(lowest,id):id;
    const card=el('article','card mb-3 chat-message');card.dataset.id=id;card.classList.toggle('chat-mine',row.user===app.dataset.user);
    card.dataset.author=row.user;avatarColor(row.avatar).then(color=>{card.style.borderInlineStartColor=color;});
    const body=el('div','card-body'),meta=el('div','chat-message-header mb-2'),author=el('div','chat-author');author.append(avatar(row.user,row.avatar),el('strong','',row.user));meta.append(author);
    const details=el('div','chat-message-details'),date=el('time','small text-body-secondary',new Date(row.datetime.replace(' ','T')+'Z').toLocaleString('pl-PL')+(row.edited_at&&!row.deleted_at?' (edytowana)':''));date.dateTime=row.datetime.replace(' ','T')+'Z';details.append(date);
    if(row.user===app.dataset.user&&!row.deleted_at){
     const menu=el('details','chat-actions'),toggle=el('summary','chat-action-toggle','☰');toggle.setAttribute('aria-label','Opcje wiadomości');menu.append(toggle);const panel=el('div','chat-action-panel');
     for(const [label,action] of [['Edytuj',()=>startEdit(row)],['Usuń',()=>removeMessage(row)]]){const button=el('button','btn btn-sm text-start',label);button.type='button';button.addEventListener('click',()=>{menu.open=false;action();},{signal});panel.append(button);}menu.append(panel);details.append(menu);
    }
    meta.append(details);body.append(meta);
    if(row.deleted_at)body.append(el('p','text-body-secondary fst-italic mb-0','Wiadomość usunięta'));
    else if(row.kind==='text')body.append(el('p','chat-text mb-0',row.message));
    else{
     if(row.caption)body.append(el('p','chat-text',row.caption));
     const url='chat_file.php?id='+id;let media;
     if(row.kind==='image'){const link=el('a');link.href=url;link.target='_blank';link.rel='noopener';media=el('img','chat-media');media.src=url;media.alt=row.filename;media.loading='lazy';link.append(media);body.append(link);}
     else if(row.kind==='audio'||row.kind==='video'){media=el(row.kind,'chat-media');media.controls=true;media.preload='metadata';if(row.kind==='video'){media.muted=true;media.autoplay=true;media.playsInline=true;}media.src=url;body.append(media);}
     const link=el('a','d-block mt-2','Pobierz: '+row.filename);link.href=url+'&download=1';link.setAttribute('download','');body.append(link);
     if(media)media.addEventListener(row.kind==='image'?'load':'loadedmetadata',()=>{if(initial||nearBottom)history.scrollTop=history.scrollHeight;},{once:true,signal});
    }
    card.append(body);const old=list.querySelector('[data-id="'+id+'"]');if(old){old.replaceWith(card);continue;}const next=Array.from(list.children).find(n=>Number(n.dataset.id)>id);list.insertBefore(card,next||null);
   }
   empty.hidden=seen.size>0;if(!seen.size)empty.textContent='Brak wiadomości. Napisz pierwszą wiadomość poniżej.';
   if(loadingOlder)history.scrollTop+=history.scrollHeight-previousHeight;else if(initial||nearBottom)history.scrollTop=history.scrollHeight;
  }
  async function json(url,options={}){const response=await fetch(url,{credentials:'same-origin',signal,...options});if(response.redirected)throw Error('Sesja wygasła. Odśwież stronę i zaloguj się ponownie.');let data;try{data=await response.json();}catch(e){throw Error('Nie udało się odczytać odpowiedzi serwera.');}if(!response.ok)throw Error(data.error||'Nie udało się wykonać operacji.');return data;}
  function query(extra=''){return 'chat_api.php?peer='+encodeURIComponent(selected||'')+extra;}
  async function poll(){
   if(stopped||polling)return;polling=true;const captured=version,first=!highest;
   try{const data=await json(query('&after='+highest+'&floor='+lowest));if(captured!==version)return;users(data.users,data.profiles);if(captured!==version)return;if(selected!==null){render(data.messages,first);render((data.updates||[]).filter(row=>seen.has(Number(row.idk))));if(first)older.hidden=!data.more;}status.textContent='Na żywo · aktualizacja automatyczna';}
   catch(e){if(e.name!=='AbortError')status.textContent=e.message;}
   finally{polling=false;if(!stopped){clearTimeout(timer);timer=setTimeout(poll,captured===version?1500:0);}}
  }
  older.addEventListener('click',async()=>{const captured=version;older.disabled=true;try{const data=await json(query('&before='+lowest));if(captured!==version)return;render(data.messages,false,true);older.hidden=!data.more;}catch(e){if(e.name!=='AbortError')error.textContent=e.message;}finally{older.disabled=false;}},{signal});
  app.querySelector('#chat-attach').addEventListener('click',()=>file.click(),{signal});file.addEventListener('change',fileLabel,{signal});app.querySelector('#chat-remove-file').addEventListener('click',()=>{file.value='';fileLabel();},{signal});
  app.querySelector('#chat-cancel-edit').addEventListener('click',cancelEdit,{signal});
  text.addEventListener('input',resize,{signal});text.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();form.requestSubmit();}},{signal});
  form.addEventListener('submit',async event=>{
   event.preventDefault();if(sending||!recipient.value)return;if(!editing&&!text.value.trim()&&!file.files.length){error.textContent='Wpisz wiadomość lub wybierz plik.';text.focus();return;}
   const payload=new FormData(form),captured=version;if(editing){payload.set('action','edit');payload.set('id',editing);payload.delete('attachment');}sending=true;fields.disabled=true;form.setAttribute('aria-busy','true');error.textContent='';
   try{await json('chat_api.php',{method:'POST',body:payload});cancelEdit();file.value='';fileLabel();resize();if(captured===version){history.scrollTop=history.scrollHeight;clearTimeout(timer);if(!polling)await poll();}}
   catch(e){if(e.name!=='AbortError')error.textContent=e.message;}
   finally{sending=false;fields.disabled=!selected;form.removeAttribute('aria-busy');if(selected)text.focus();}
  },{signal});
  document.addEventListener('click',event=>{
   for(const menu of app.querySelectorAll('.chat-actions[open]')){
    if(!menu.contains(event.target))menu.open=false;
   }
  },{signal});
  let dragDepth=0;
  const isFileDrag=event=>Array.from(event.dataTransfer?.types||[]).includes('Files');
  app.addEventListener('dragenter',event=>{if(!isFileDrag(event))return;event.preventDefault();dragDepth++;app.classList.add('chat-dragging');},{signal});
  app.addEventListener('dragover',event=>{if(!isFileDrag(event))return;event.preventDefault();event.dataTransfer.dropEffect=selected&&!sending?'copy':'none';},{signal});
  app.addEventListener('dragleave',event=>{if(!isFileDrag(event))return;dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)app.classList.remove('chat-dragging');},{signal});
  app.addEventListener('drop',event=>{if(!isFileDrag(event))return;event.preventDefault();dragDepth=0;app.classList.remove('chat-dragging');if(!selected||sending){error.textContent='Najpierw wybierz rozmowę.';return;}const dropped=event.dataTransfer.files;if(!dropped.length)return;if(editing)cancelEdit();const transfer=new DataTransfer();transfer.items.add(dropped[0]);file.files=transfer.files;fileLabel();error.textContent=dropped.length>1?'Dodano pierwszy plik. Wysyłaj pliki pojedynczo.':'';text.focus();},{signal});
  poll();
 }
 document.addEventListener('DOMContentLoaded',init);
})();
