<?php declare(strict_types=1);
require_once __DIR__.'/common.php';
function chat_user(): array {
    $u=current_user();if(!$u){http_response_code(401);exit('Wymagane logowanie.');}return $u;
}
function chat_admin(array $u): bool {return in_array($u['username'],['admin','Dawid24p'],true);}
function chat_messages(mysqli $d,array $u,int $after,int $before=0,string $peer='',bool $updates=false): array {
    $order=$after>0?'ASC':'DESC';
    $extra=$updates?' AND (edited_at IS NOT NULL OR deleted_at IS NOT NULL)':'';
    $limit=$updates?'':' LIMIT 50';
    $s=$d->prepare('SELECT m.*,u.avatar FROM messages m LEFT JOIN z6_users u ON u.username=m.user WHERE (user=? OR recipient=? OR ?=1) AND (?=\'\' OR (user=? AND recipient=?) OR (user=? AND recipient=?)) AND idk>? AND (?=0 OR idk<?) '.$extra.' ORDER BY idk '.$order.$limit);
    $name=$u['username'];$admin=(int)chat_admin($u);$s->bind_param('ssisssssiii',$name,$name,$admin,$peer,$name,$peer,$peer,$name,$after,$before,$before);$s->execute();return $s->get_result()->fetch_all(MYSQLI_ASSOC);
}
function chat_authorized_message(mysqli $d,array $u,int $id): ?array {
    $s=$d->prepare('SELECT * FROM messages WHERE idk=? AND (user=? OR recipient=? OR ?=1)');$name=$u['username'];$admin=(int)chat_admin($u);$s->bind_param('issi',$id,$name,$name,$admin);$s->execute();return $s->get_result()->fetch_assoc();
}
function chat_modify(mysqli $d,array $u,int $id,string $action,string $text): void {
    if(!in_array($action,['edit','delete'],true))throw new InvalidArgumentException('Nieprawidłowa operacja.');
    if(mb_strlen($text)>10000)throw new InvalidArgumentException('Wiadomość może mieć do 10 000 znaków.');
    $d->begin_transaction();$path=null;
    try{
        $s=$d->prepare('SELECT * FROM messages WHERE idk=? AND user=? FOR UPDATE');$name=$u['username'];$s->bind_param('is',$id,$name);$s->execute();$row=$s->get_result()->fetch_assoc();
        if(!$row||$row['deleted_at']!==null)throw new InvalidArgumentException('Wiadomość jest niedostępna lub nie należy do Ciebie.');
        if($action==='edit'){
            if($row['kind']==='text'&&trim($text)==='')throw new InvalidArgumentException('Wpisz treść wiadomości.');
            $column=$row['kind']==='text'?'message':'caption';
            $s=$d->prepare("UPDATE messages SET `$column`=?,edited_at=UTC_TIMESTAMP(6) WHERE idk=?");$s->bind_param('si',$text,$id);$s->execute();
        }else{
            if($row['kind']!=='text'&&preg_match('~\A[A-Za-z0-9_.-]{3,20}/messages/[a-f0-9]{48}\z~D',$row['message']))$path=CLOUD_STORAGE.'/'.$row['message'];
            $s=$d->prepare("UPDATE messages SET message='',caption=NULL,kind='text',filename=NULL,mime=NULL,deleted_at=UTC_TIMESTAMP(6) WHERE idk=?");$s->bind_param('i',$id);$s->execute();
        }
        $d->commit();
    }catch(Throwable $e){$d->rollback();throw $e;}
    if($path!==null&&is_file($path)&&!unlink($path))error_log('Z9: nie udało się usunąć załącznika wiadomości '.$id);
}
