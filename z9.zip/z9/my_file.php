<?php declare(strict_types=1);
header('Content-Type: application/json; charset=UTF-8');header('Cache-Control: no-store');
readfile(__DIR__.'/my_file.json');
