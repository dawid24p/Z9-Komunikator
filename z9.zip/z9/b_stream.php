<?php declare(strict_types=1);require __DIR__.'/common.php';require_login();session_write_close();
header('Content-Type: text/event-stream; charset=UTF-8');header('Cache-Control: no-cache, no-store, must-revalidate');header('X-Accel-Buffering: no');ini_set('zlib.output_compression','0');while(ob_get_level()>0)ob_end_flush();echo "retry: 2000\n\n";flush();
try{$d=db();$until=microtime(true)+20;do{
$row=$d->query('SELECT id,x1,x2,x3,x4,x5,datetime FROM pomiary ORDER BY id DESC LIMIT 1')->fetch_assoc();
if(!$row){echo "event: empty\ndata: Brak pomiarów. Dodaj pierwszy pomiar formularzem.\n\n";}
else{$values=[];for($i=1;$i<=5;$i++)$values['x'.$i]=(float)$row['x'.$i];
if($format==='json')$payload=json_encode($values,JSON_THROW_ON_ERROR);
elseif($format==='xml'){$payload='<pomiary>';foreach($values as $k=>$v)$payload.='<'.$k.'>'.$v.'</'.$k.'>';$payload.='</pomiary>';}
else $payload=implode("\t",$values);
echo 'data: '.$payload."\n\n";
}flush();if(connection_aborted())break;sleep(1);
}while(microtime(true)<$until);$d->close();}catch(Throwable $e){error_log('Z9 B: błąd strumienia');echo "event: stream-error\ndata: Błąd odczytu pomiarów.\n\n";flush();}
