'use strict';
(function(){
 let cleanup=()=>{};
 function init(){
  cleanup();let stopped=false,timer=null,request=null,source=null;
  cleanup=()=>{stopped=true;clearInterval(timer);if(request)request.abort();if(source)source.close();};
  const pollBox=document.querySelector('[data-ajax-json]');
  if(pollBox){let count=0;
   const poll=()=>{if(stopped||request)return;request=jQuery.ajax({url:'my_file.json',dataType:'json',type:'GET',cache:false,timeout:8000})
    .done(data=>{if(stopped)return;if(!data||typeof data.imie!=='string'){pollBox.querySelector('[data-poll-status]').textContent='Nieprawidłowy format danych: wymagane pole imie.';return;}pollBox.querySelector('.status').textContent=data.imie;pollBox.querySelector('[data-poll-status]').textContent='Odczyt: '+new Date().toLocaleTimeString('pl-PL')+' · liczba pobrań: '+(++count);})
    .fail((xhr,status,error)=>{if(stopped||status==='abort')return;pollBox.querySelector('[data-poll-status]').textContent='Nie udało się pobrać JSON. Ponowna próba za 2 sekundy.';console.error('Z9 AJAX:',status,error);})
    .always(()=>{request=null;});};poll();timer=setInterval(poll,2000);
  }
  const box=document.querySelector('[data-ajax-stream]');
  if(box){const status=box.querySelector('[data-stream-status]');if(!window.EventSource){status.textContent='Przeglądarka nie obsługuje EventSource.';return;}
   source=new EventSource('text_from_db.php');
   source.onopen=()=>{status.textContent='Połączono · aktualizacja automatyczna';};
   source.onmessage=event=>{try{const data=JSON.parse(event.data);box.querySelector('#date').textContent=data.text1;box.querySelector('[data-stream-date]').textContent=data.datetime?'Wpis #'+data.id+' · '+new Date(data.datetime.replace(' ','T')+'Z').toLocaleString('pl-PL'):'';status.textContent='Połączono · aktualizacja automatyczna';}catch(error){status.textContent='Nieprawidłowe dane ze strumienia.';console.error('Z9 SSE:',error);}};
   source.onerror=()=>{status.textContent='Łączenie ponowne…';};
   source.addEventListener('stream-error',()=>{status.textContent='Błąd odczytu. Trwa ponawianie połączenia…';});
  }
 }
 document.addEventListener('DOMContentLoaded',init);window.addEventListener('pagehide',()=>cleanup());
})();
