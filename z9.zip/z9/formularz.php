<?php declare(strict_types=1);require __DIR__.'/common.php';head('Dodaj tekst do bazy');$_SESSION['ajax_csrf']??=bin2hex(random_bytes(32)); ?>
<?php if(isset($_SESSION['ajax_notice'])): ?><div class="alert alert-success" role="status"><?=h($_SESSION['ajax_notice'])?></div><?php unset($_SESSION['ajax_notice']);endif; ?>
<?php if(isset($_SESSION['ajax_error'])): ?><div class="alert alert-warning" role="alert"><?=h($_SESSION['ajax_error'])?></div><?php unset($_SESSION['ajax_error']);endif; ?>
<form action="dodaj.php" method="post" class="card" data-full-navigation="true"><div class="card-body">
<input type="hidden" name="csrf" value="<?=h($_SESSION['ajax_csrf'])?>">
<label class="form-label" for="text1">Tekst nowego wpisu</label><textarea class="form-control mb-3" name="text1" id="text1" rows="4" maxlength="2000" required></textarea>
<button class="btn btn-primary" type="submit">Zapisz wpis</button>
</div></form>
<p class="mt-3"><a href="index2.php" target="_blank" rel="noopener">Otwórz podgląd na żywo</a> · <a href="index.php">Zadanie 9</a></p>
<?php foot(); ?>
