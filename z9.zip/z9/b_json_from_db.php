<?php declare(strict_types=1);$format='json';require __DIR__.'/b_stream.php';
