<?php
return ['host'=>'localhost','user'=>'srv126086_z9','pass'=>'kqc8NsTpaEGbx8X7J3BD','name'=>'srv126086_z9'];
